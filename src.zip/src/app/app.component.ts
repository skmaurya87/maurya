import { Component } from '@angular/core';
declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'admin';
}
$(document).ready(function () {
  $("#menuslist li").click(function(){
    $(this) .parents('#menuslist') .find('li').removeClass("active");
    $(this).addClass("active");
  });
});
