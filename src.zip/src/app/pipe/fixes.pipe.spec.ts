import { FixesPipe } from './fixes.pipe';

describe('FixesPipe', () => {
  it('create an instance', () => {
    const pipe = new FixesPipe();
    expect(pipe).toBeTruthy();
  });
});
