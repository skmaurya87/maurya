import { Component, OnInit } from '@angular/core';
declare var jquery:any;
declare var $ :any;
@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
  myCarouselImages =[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20].map((i)=>`https://picsum.photos/g/800/600?image=${i}`);
  ngOnInit() {
    $(function() {
    	$('img').on('click', function() {
			$('.enlargeImageModalSource').attr('src', $(this).attr('src'));
			$('#enlargeImageModal').modal('show');
		});
});


  }

}
