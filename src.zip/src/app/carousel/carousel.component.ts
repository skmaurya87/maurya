import { Component, OnInit } from '@angular/core';
declare var jquery:any;
declare var $ :any;
@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {
  images=[
    {"img":"https://cdn.pixabay.com/photo/2017/04/01/11/03/animals-2193366_1280.jpg", "badge":"Light badge", "text":"Nulla vitae elit libero, a pharetra augue mollis interdum 1", "h3": "First slide label 1", "btn":"https://themeforest.net/"},
    {"img":"https://cdn.pixabay.com/photo/2017/04/01/11/03/animals-2193366_1280.jpg", "badge":"Light badge new", "text":"Nulla vitae elit libero, a pharetra augue mollis interdum. 2", "h3": "First slide label 2", "btn":"https://themeforest.net/"},
    {"img":"https://cdn.pixabay.com/photo/2017/04/01/11/03/animals-2193366_1280.jpg", "badge":"Light badge old", "text":"Nulla vitae elit libero, a pharetra augue mollis interdum. 3", "h3": "First slide label 3", "btn":"https://themeforest.net/"},
    {"img":"https://cdn.pixabay.com/photo/2017/04/01/11/03/animals-2193366_1280.jpg", "badge":"Light badge prev", "text":"Nulla vitae elit libero, a pharetra augue mollis interdum. 4", "h3": "First slide label 4", "btn":"https://themeforest.net/"},
    {"img":"https://cdn.pixabay.com/photo/2017/04/01/11/03/animals-2193366_1280.jpg", "badge":"Light badge next", "text":"Nulla vitae elit libero, a pharetra augue mollis interdum. 5", "h3": "First slide label 5", "btn":"https://themeforest.net/"},];
  number = [0,1,2,3,4];
  constructor() { }
  ngOnInit() {
    for(let i = 0; i < 5; i++) {
      console.log(i);
    }
    $(document).ready(function(){
      $("#myDIV").addClass("active")
      $(".carousel-indicators>li:first-child").addClass("active");
    });
  }

}
