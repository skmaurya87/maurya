import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {HttpClientModule} from '@angular/common/http';
import {Routes, RouterModule} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ContentComponent } from './content/content.component';
import { StarterComponent } from './starter/starter.component';
import { DropnavbarComponent } from './dropnavbar/dropnavbar.component';
import { CarouselComponent } from './carousel/carousel.component';
import { OwlComponent } from './owl/owl.component';
import { OwlModule } from 'ngx-owl-carousel';
import { ScrollAnimationComponent } from './scroll-animation/scroll-animation.component';
import { GalleryComponent } from './gallery/gallery.component';
import { ThumbCrauselComponent } from './thumb-crausel/thumb-crausel.component';
import { FixesPipe } from './pipe/fixes.pipe';
import { ServiceComponent } from './service/service.component';

const route: Routes = [
  {path: '', component:StarterComponent},
  {path: 'starter', component:StarterComponent},
  {path: 'dropnavbar', component:DropnavbarComponent},
  {path: 'carousel', component:CarouselComponent},
  {path: 'owl', component:OwlComponent},
  {path: 'scrollAnimation', component:ScrollAnimationComponent},
  {path: 'gallery', component:GalleryComponent},
  {path: 'thumbCrausel', component:ThumbCrauselComponent},
  {path: 'service' , component:ServiceComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    NavbarComponent,
    ContentComponent,
    StarterComponent,
    DropnavbarComponent,
    CarouselComponent,
    OwlComponent,
    ScrollAnimationComponent,
    GalleryComponent,
    ThumbCrauselComponent,
    FixesPipe,
    ServiceComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    AngularFontAwesomeModule,
    RouterModule.forRoot(route),
    HttpClientModule,
    OwlModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
