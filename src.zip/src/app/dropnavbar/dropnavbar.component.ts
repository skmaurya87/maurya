import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dropnavbar',
  templateUrl: './dropnavbar.component.html',
  styleUrls: ['./dropnavbar.component.css']
})
export class DropnavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  
  }

}
